package dc.aap.analyzed;

import java.io.*;

public class SomeClass {
	public Class1 class1At;
	public Class2 class2At;
	public int pepe;

	public static void entryPoint() {
		boolean entry = true;
		int i = 0;
		int x = 0;

		if (i != 1) {
			i = 1;
			x = x + 2;
		} else {
			i = 2;
			x = x + i;
		}
		i = i + 1;
		x = x + 3;

	}

	public static int pepe(int x, int y) {
		return x;
	}

	public SomeClass() {
		Class1 c1 = new Class1();
		class1At = c1;
		pepe = 0;
	}

	public Class2 crazyMethod(Class1 cl1) {
		class1At = cl1;
		return class2At;
	}

	public static class Class1 {
		public Class1() {
			intAt = 1;
		}

		public Class2 class2At;
		public int intAt;
	}

	public static class Class2 {
		public int intAt;
	}
}