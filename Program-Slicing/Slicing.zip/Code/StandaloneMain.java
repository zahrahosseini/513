package dc.aap;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import soot.Body;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.Unit;
import soot.Value;
import soot.toolkits.graph.CompleteUnitGraph;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.MHGDominatorsFinder;
import soot.toolkits.graph.MHGPostDominatorsFinder;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.SimpleLiveLocals;
import soot.toolkits.scalar.SimpleLocalUses;
import soot.toolkits.scalar.SmartLocalDefs;
import soot.toolkits.scalar.UnitValueBoxPair;
import soot.util.cfgcmd.CFGToDotGraph;
import soot.util.dot.DotGraph;

public class StandaloneMain {
	private static void writeinFile(String FileName, String Output) throws IOException {
		FileWriter fw = new FileWriter(FileName);

		fw.write(Output);

		fw.close();
	}

	public static void main(String[] args) throws IOException {
		File someClassFile = new File("./bin/").getAbsoluteFile();
		soot.options.Options.v().set_keep_line_number(true);
		soot.options.Options.v().setPhaseOption("jb", "use-original-names:true");
		soot.options.Options.v().setPhaseOption("cg", "verbose:true");
		Scene.v().setSootClassPath(Scene.v().getSootClassPath() + File.pathSeparator + someClassFile);
		String ClassName = "dc.aap.analyzed.SomeClass";
		SootClass c = Scene.v().loadClassAndSupport(ClassName);
		c.setApplicationClass();
		Scene.v().loadNecessaryClasses();
		// System.out.println(c.getMethodCount());
		List<SootMethod> m1 = c.getMethods();
		LineCounter LOC = new LineCounter();
		String LocationoftestFile = "/Users/zh/Desktop/ws/PointsTo/src/dc/aap/analyzed/SomeClass.java";
		StringBuilder Output1 = new StringBuilder();
		StringBuilder Output2 = new StringBuilder();
		;
		Output1.append("LOC" + LOC.LOC(LocationoftestFile) + "\n");
		// System.out.println("LOC"+LOC.LOC("/Users/zh/Desktop/ws/PointsTo/src/dc/aap/analyzed/sc.java"));

		// for(int iterator=0; iterator<c.getMethodCount();iterator++)
		// {
		long startTime = System.currentTimeMillis();

		//SootMethod m = c.getMethodByName("stopAtThisFloor");// m1.get(iterator); //
		SootMethod m = c.getMethodByName("entryPoint");// m1.get(iterator); //

		Body b = m.retrieveActiveBody();
		// System.out.println(b);
		// System.out.println("ZAHRA");
		UnitGraph g = new ExceptionalUnitGraph(b); // = new BriefUnitGraph(b);
		// UnitGraph g = new BriefUnitGraph(b);
		// System.out.println(g);
		CFGToDotGraph CTD = new CFGToDotGraph();
		DotGraph DG = CTD.drawCFG(g, b);
		DG.plot("g.dot");
		Callsite x = new Callsite(g);
		///////
		UnitGraph graph = new CompleteUnitGraph(b);
		x.DD(graph);
//		x.Backward("i = i + 1");
//		x.Forward("i = 0");
	//x.chopping("if $i4 != -1 goto $r8 = this.<dc.aap.analyzed.FloorControl: dc.aap.analyzed.Elevator elevator>", "if $z0 == 0 goto return");
		//	For main	x.chopping("i = 0", "if $i1 == 300 goto i = i + 1");
		x.chopping("i = 0", "x = x + 3");
		try {
			x.WriteinDot("DD.dot", 0);
			x.WriteinDot("CD.dot", 1);
			x.WriteinDot("PDG.dot", 2);
			x.WriteinDot("BB.dot", 3);
			x.WriteinDot("FF.dot", 4);
			x.WriteinDot("CC.dot", 5);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Output1.append("Function name:"+m.getName()+",
		// "+"AVG:"+Float.toString(x.Get_AVG())+", ");
		// //System.out.println("AVG:"+Float.toString(x.Get_AVG()));
		//
		// long endTime = System.currentTimeMillis();
		// long totalTime = endTime - startTime;
		// //System.out.println("TIME"+totalTime+"ms");
		// Output1.append("TIME:"+totalTime+"ms"+"\n");
		// Output2.append("Method:"+ m.getName()+"\n");
		// //System.out.println(m.getName());
		// Output2.append(x.P2S(LocationoftestFile));
		// //System.out.println(x.P2S(LocationoftestFile));
		//
		// //x.getPointto();
		// //System.out.println(x.LineMap.toString());
		// //}
		// writeinFile("/Users/zh/Desktop/ws/PointsTo/src/dc/aap/analyzed/output1.txt",
		// Output1.toString());
		// writeinFile("/Users/zh/Desktop/ws/PointsTo/src/dc/aap/analyzed/output2.txt",
		// Output2.toString());
		//
		// System.out.println(Output2.toString());
		// System.out.println(Output1.toString());
		// //analysis.getPointsToGraph().toDotFile();
		// //System.out.println("ZAHRA");
		// analysis.getPointto();
		// System.out.println(analysis.PointsTo);
		// System.out.println(analysis.LineMap);

		// System.out.println(analysis.getPointsToGraph());
	}
}
